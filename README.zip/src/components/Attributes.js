import logopng from "../EGLogo.png";

const Attributes = (props) => {
  const logo = <img src={logopng}></img>;
  return logo;
};

export default Attributes;
