const ConditionalRenderingWeekends = () => {
  return <h1>Rest day!</h1>;
};

export default ConditionalRenderingWeekends;
