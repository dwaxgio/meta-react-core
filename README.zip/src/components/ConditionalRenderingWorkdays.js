const ConditionalRenderingWorkdays = () => {
  return <h1>Work day!</h1>;
};

export default ConditionalRenderingWorkdays;
