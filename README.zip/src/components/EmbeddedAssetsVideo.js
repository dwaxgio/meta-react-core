import ReactPlayer from "react-player/youtube";

const EmbeddedAssetsVideo = () => {
  return <ReactPlayer url="https://www.youtube.com/watch?v=XMbvcp480Y4" />;
};

export default EmbeddedAssetsVideo;
