function Footer() {
  return (
    <div className="copyright">
      <p>Made by Edward Giraldo</p>
    </div>
  );
}

export default Footer;
