const ObservingStateChild = (props) => {
  return <h1>{props.message}</h1>;
};

export default ObservingStateChild;
