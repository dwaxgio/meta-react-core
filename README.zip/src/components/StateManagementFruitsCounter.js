const StateManagementFruitsCounter = (props) => {
  return <h2>Total fruits: {props.fruits.length}</h2>;
};

export default StateManagementFruitsCounter;
