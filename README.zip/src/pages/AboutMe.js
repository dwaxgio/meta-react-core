const AboutMe = () => {
  return <h1>About Me</h1>;
};

export default AboutMe;
