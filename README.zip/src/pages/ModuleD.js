import Calculator from "../components/Calculator";
const ModuleD = () => {
  return (
    <>
      <h1>Module D</h1>
      <h2>Calculator app / Concepts wrap up</h2>
      <Calculator/>
    </>
  );
};

export default ModuleD;
